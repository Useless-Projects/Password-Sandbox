# Password Sandbox

[![PyPI - Version](https://img.shields.io/pypi/v/password-sandbox?style=flat-square&logo=PyPI&label=Version%3A)](https://pypi.org/project/password-sandbox)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/password-sandbox?style=flat-square&logo=python&logoColor=%23ffd343&label=Version%20of%20Python%3A
)](https://pypi.org/project/password-sandbox)
![License](https://img.shields.io/badge/License%3A-MIT-red?style=flat-square)
![PyPI - Downloads](https://img.shields.io/pypi/dm/password-sandbox?style=flat-square&label=Downloads%3A)
![GitHub - Last Commit](https://img.shields.io/github/last-commit/Useless-Projects/password-sandbox?style=flat-square&label=Last%20Commit%3A)
![Size](https://img.shields.io/github/repo-size/Useless-Projects/password-sandbox?style=flat-square&label=Size%3A&color=teal)

-----

## Installation

```console
pip install password-sandbox
```

## Usage

```python
import password_sandbox
```

-----

[Icons made by juicy_fish - Flaticon](https://www.flaticon.com/authors/juicy-fish)
